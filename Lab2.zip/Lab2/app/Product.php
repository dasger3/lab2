<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    public static function filter($var) {
        if($var == "only1") {
            return static::where('type', 1)->get();
        }
        if($var == "only2") {
            return static::where('type', 2)->get();
        }
        if($var == "only3") {
            return static::where('type', 3)->get();
        }
    }
}
