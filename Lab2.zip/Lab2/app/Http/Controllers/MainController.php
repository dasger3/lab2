<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;

class MainController extends Controller
{
    public function _index() {
        $products = Product::get();
        return view('index', compact('products'));
    }
    public function _Categories() {
        return view('Categories');
    }
    public function _detailed($code) {
        $products = Product::where('code', $code)->first();
        return view('detailed', compact('products'));
    }
    public function _filter($filter) {
        $products = Product::filter($filter);
        return view('index', compact('products'));
    }
}
