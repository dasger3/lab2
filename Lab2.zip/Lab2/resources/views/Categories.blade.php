@extends('template')
@section('header')
    <h1><a href = "/" style = "text-decoration:none; margin-right: 10px;">Home</a></h1>
    <h1><a href = "/Categories" style = text-decoration:none;>Categories</a></h1>
@endsection
@section('content')
    <div><a href = "Categories/only1" style = text-decoration:none;>1 type</a></div>
    <div><a href = "Categories/only2" style = text-decoration:none;>2 type</a></div>
    <div><a href = "Categories/only3" style = text-decoration:none;>3 type</a></div>
    @endsection
