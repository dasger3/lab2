@extends('template')
@section('header')
    <h1><a href = "/" style = "text-decoration:none; margin-right: 10px;">Home</a></h1>
    <h1><a href = "/Categories" style = text-decoration:none;>Categories</a></h1>
@endsection
@section('content')
    <h2>{{$products->body}}`s id: {{$products->id}}</h2>
    <h2>{{$products->body}}`s body: {{$products->body}}</h2>
    <h2>{{$products->body}}`s code: {{$products->code}}</h2>
@endsection

