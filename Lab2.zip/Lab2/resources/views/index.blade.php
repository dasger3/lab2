@extends('template')
@section('header')
    <h1><a href = "/" style = "text-decoration:none; margin-right: 10px;">Home</a></h1>
    <h1><a href = "/Categories" style = text-decoration:none;>Categories</a></h1>
@endsection
@section('content')
    @foreach($products as $product)
        @if(isset($_GET['value']))
            @if($_GET['value'] == 1 and $product->type == 1)
                <div ><a href = "/{{$product->code}}"style =text-decoration:none;>{{$product->body}}</a></div>
            @elseif($_GET['value'] == 2 and $product->type == 2)
                <div ><a href = "/{{$product->code}}"style =text-decoration:none;>{{$product->body}}</a></div>
            @elseif($_GET['value'] == 3 and $product->type == 3)
                <div ><a href = "/{{$product->code}}"style =text-decoration:none;>{{$product->body}}</a></div>
            @elseif($_GET['value'] == 4)
                <div ><a href = "/{{$product->code}}"style =text-decoration:none;>{{$product->body}}</a></div>
            @endif
        @else
            <div ><a href = "/{{$product->code}}"style =text-decoration:none;>{{$product->body}}</a></div>
        @endif
    @endforeach
    <form method = "GET">
        <button name = "value" value = "1">Only 1 type</button>
        <button name = "value" value = "2">Only 2 type</button>
        <button name = "value" value = "3">Only 3 type</button>
        <button name = "value" value = "4">All types</button>
    </form>
    @endsection
