<?php $__env->startSection('header'); ?>
    <h1><a href = "/" style = "text-decoration:none; margin-right: 10px;">Home</a></h1>
    <h1><a href = "/Categories" style = text-decoration:none;>Categories</a></h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div><a href = "Categories/only1" style = text-decoration:none;>1 type</a></div>
    <div><a href = "Categories/only2" style = text-decoration:none;>2 type</a></div>
    <div><a href = "Categories/only3" style = text-decoration:none;>3 type</a></div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\Lab2\resources\views/Categories.blade.php ENDPATH**/ ?>