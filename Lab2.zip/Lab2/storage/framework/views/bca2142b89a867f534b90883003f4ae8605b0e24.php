<?php $__env->startSection('header'); ?>
    <h1><a href = "/" style = "text-decoration:none; margin-right: 10px;">Home</a></h1>
    <h1><a href = "/Categories" style = text-decoration:none;>Categories</a></h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(isset($_GET['value'])): ?>
            <?php if($_GET['value'] == 1 and $product->type == 1): ?>
                <div ><a href = "/<?php echo e($product->code); ?>"style =text-decoration:none;><?php echo e($product->body); ?></a></div>
            <?php elseif($_GET['value'] == 2 and $product->type == 2): ?>
                <div ><a href = "/<?php echo e($product->code); ?>"style =text-decoration:none;><?php echo e($product->body); ?></a></div>
            <?php elseif($_GET['value'] == 3 and $product->type == 3): ?>
                <div ><a href = "/<?php echo e($product->code); ?>"style =text-decoration:none;><?php echo e($product->body); ?></a></div>
            <?php elseif($_GET['value'] == 4): ?>
                <div ><a href = "/<?php echo e($product->code); ?>"style =text-decoration:none;><?php echo e($product->body); ?></a></div>
            <?php endif; ?>
        <?php else: ?>
            <div ><a href = "/<?php echo e($product->code); ?>"style =text-decoration:none;><?php echo e($product->body); ?></a></div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <form method = "GET">
        <button name = "value" value = "1">Only 1 type</button>
        <button name = "value" value = "2">Only 2 type</button>
        <button name = "value" value = "3">Only 3 type</button>
        <button name = "value" value = "4">All types</button>
    </form>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\Lab2\resources\views/index.blade.php ENDPATH**/ ?>