<?php $__env->startSection('header'); ?>
    <h1><a href = "/" style = "text-decoration:none; margin-right: 10px;">Home</a></h1>
    <h1><a href = "/Categories" style = text-decoration:none;>Categories</a></h1>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <h2><?php echo e($products->body); ?>`s id: <?php echo e($products->id); ?></h2>
    <h2><?php echo e($products->body); ?>`s body: <?php echo e($products->body); ?></h2>
    <h2><?php echo e($products->body); ?>`s code: <?php echo e($products->code); ?></h2>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\Lab2\resources\views/detailed.blade.php ENDPATH**/ ?>