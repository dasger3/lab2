<?php

use Illuminate\Support\Facades\Route;


Route::get('/', 'MainController@_index');
Route::get('/Categories', 'MainController@_Categories');
Route::get('/Categories/{filter}','MainController@_filter');
Route::get('/{code}','MainController@_detailed');
